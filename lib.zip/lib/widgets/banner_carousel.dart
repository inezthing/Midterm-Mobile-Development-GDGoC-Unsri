import 'dart:async';
import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class BannerCarousel extends StatefulWidget {
  const BannerCarousel({super.key});

  @override
  State<BannerCarousel> createState() => _BannerCarouselState();
}

class _BannerCarouselState extends State<BannerCarousel> {
  final PageController _controller = PageController();
  int _currentIndex = 0;
  Timer? _timer;

  final List<_BannerData> _banners = [
    _BannerData(
      emoji: '♻️',
      bigEmoji: '🌿',
      decorEmojis: ['🌱', '💚', '🍃'],
      gradient: [Color(0xFFE91E8C), Color(0xFFFF6B9D)],
      title: 'Give it a new home 🏡',
      subtitle: 'Barang preloved-mu bisa jadi kebahagiaan orang lain. Kurangi waste, share the love!',
      tag: '#SustainableFashion',
    ),
    _BannerData(
      emoji: '👥',
      bigEmoji: '💬',
      decorEmojis: ['🌸', '💕', '✨'],
      gradient: [Color(0xFFC2185B), Color(0xFFE91E8C)],
      title: 'Komunitas kita 💕',
      subtitle: 'Terhubung dengan sesama kolektor, share WTS/WTB, dan temukan teman baru!',
      tag: '#WhimsifyCommunity',
    ),
    _BannerData(
      emoji: '🎀',
      bigEmoji: '👸',
      decorEmojis: ['💄', '🌺', '🎀'],
      gradient: [Color(0xFFAD1457), Color(0xFFC2185B)],
      title: 'Promo Kartini 👸',
      subtitle: '21–30 April • Diskon 10% untuk semua pengguna perempuan. Kode: KARTINI25',
      tag: 'Berlaku s/d 30 April',
    ),
  ];

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  void _startTimer() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 4), (_) {
      if (!mounted) return;
      if (!_controller.hasClients) return;
      final next = (_currentIndex + 1) % _banners.length;
      _controller.animateToPage(
        next,
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOut,
      );
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _timer = null;
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 160,
          child: PageView.builder(
            controller: _controller,
            onPageChanged: (i) => setState(() => _currentIndex = i),
            itemCount: _banners.length,
            itemBuilder: (context, index) {
              final b = _banners[index];
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: b.gradient,
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Stack(
                    children: [
                      Positioned(
                        right: -10,
                        top: -10,
                        child: Text(b.bigEmoji,
                            style: const TextStyle(fontSize: 90)),
                      ),
                      for (int i = 0; i < b.decorEmojis.length; i++)
                        Positioned(
                          right: 20.0 + i * 30,
                          bottom: 10,
                          child: Opacity(
                            opacity: 0.4,
                            child: Text(b.decorEmojis[i],
                                style: const TextStyle(fontSize: 18)),
                          ),
                        ),
                      Padding(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              b.title,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 17,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 6),
                            SizedBox(
                              width: MediaQuery.of(context).size.width * 0.55,
                              child: Text(
                                b.subtitle,
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.9),
                                  fontSize: 11.5,
                                  height: 1.4,
                                ),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: Colors.white.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: Text(
                                b.tag,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(_banners.length, (i) {
            final isActive = i == _currentIndex;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: isActive ? 20 : 6,
              height: 6,
              decoration: BoxDecoration(
                color: isActive ? AppTheme.primary : AppTheme.rose,
                borderRadius: BorderRadius.circular(3),
              ),
            );
          }),
        ),
      ],
    );
  }
}

class _BannerData {
  final String emoji;
  final String bigEmoji;
  final List<String> decorEmojis;
  final List<Color> gradient;
  final String title;
  final String subtitle;
  final String tag;

  const _BannerData({
    required this.emoji,
    required this.bigEmoji,
    required this.decorEmojis,
    required this.gradient,
    required this.title,
    required this.subtitle,
    required this.tag,
  });
}
